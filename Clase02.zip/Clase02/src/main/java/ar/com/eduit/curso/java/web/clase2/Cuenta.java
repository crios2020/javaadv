package ar.com.eduit.curso.java.web.clase2;

public class Cuenta {
    private double saldo=2000;
    
    public void debitar(double monto){
        System.out.println("-- Iniciando operación debitar --");
        synchronized(this){         // JDK 7 o sup.
            if(monto<=saldo){
                try{ Thread.sleep(2000); }catch(Exception e){}
                saldo-=monto;
            }else{
                System.out.println("-- Saldo insuficiente!!");
            }
        }
        System.out.println("-- Fin operación debitar --");
    }
    
    public void depositar(double monto){
        saldo+=monto;
    }

    public double getSaldo() {
        return saldo;
    }
    
}
