package ar.com.eduit.curso.java.web.clase1;

import java.text.DecimalFormat;
import javax.swing.JTextField;

public class CronometroR implements Runnable{
    
    private JTextField txt;
    private int cont=0;
    private boolean correr=false;
    private final static DecimalFormat df=new DecimalFormat("000000");

    public CronometroR(JTextField txt) {
        this.txt = txt;
    }
   
    @Override
    public void run() {
        while(true){
            if(correr){
                cont++;
                txt.setText(df.format(cont));
            }
            try { Thread.sleep(1000); } catch(Exception e) {}
        }
    }
    
    public void start(){
        correr=true;
    }
    
    public void pause(){
        correr=false;
    }
    
    public void stop(){
        correr=false;
        cont=0;
        txt.setText("000000");
    }
    
}
