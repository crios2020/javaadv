package ar.com.eduit.curso.java.web.clase2;

public class Clase02 {
    public static void main(String[] args) {
        
        /*
                Ciclo de Vida de un Thread
        
            NEW                 RUNNABLE        TIMEWAITING         BLOCKED     TERMINATED
            
            new Thread();       .start();       .sleep() .wait()    I/O         muerte natural
                                                .suspend()                      asesinato   .stop()
        
        */
       
        
        /*
                    Manejo de Prioridades
        
            Java        Windows         Linux           MacOS
        
            1           1               1               - 10
            2
            3
            4
            5           50              10              0
            6
            7
            8
            9
            10          100             20              10
        
        
        */
        
        
        HiloT hiloT1=new HiloT("hiloT1");
        HiloT hiloT2=new HiloT("hiloT2",800);
        HiloT hiloT3=new HiloT("hiloT3",600);
        HiloT hiloT4=new HiloT("hiloT4",400);
        
        hiloT4.setPriority(Thread.MAX_PRIORITY);
        hiloT2.setPriority(Thread.NORM_PRIORITY);
        hiloT3.setPriority(Thread.NORM_PRIORITY);
        hiloT1.setPriority(Thread.MIN_PRIORITY);
        
        System.out.println(hiloT1.getState());
        System.out.println(hiloT1.isAlive());
        
        try{
            hiloT1.start();
            //hiloT1.join();
            hiloT2.start();
            //hiloT2.join();
            hiloT3.start();
            //hiloT3.join();
            hiloT4.start();
            //hiloT4.join();
            
            System.out.println(hiloT1.getState());
            System.out.println(hiloT1.isAlive());
            
            hiloT1.join();
            hiloT2.join();
            hiloT3.join();
            hiloT4.join();
            
        }catch(Exception e){}

        
 
        
        // YIELD
        
        
        
        //try { Thread.sleep(11000); } catch(Exception e) {} 
        System.out.println("-- Fin del programa --");
        System.out.println(hiloT1.getState());
        System.out.println(hiloT1.isAlive());
    }
}
