package ar.com.eduit.curso.java.web.clase1;

public class HiloT extends Thread {
    private String nombre;

    public HiloT(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public void run() {
        //El método .run() es el unico que puede ejecutarse en un nuevo thread.
        
        for(int a=1;a<=10;a++){
            System.out.println(nombre+" "+a);
            try { Thread.sleep(1000); } catch(Exception e) {}
        }
        
    }
    
    
}
