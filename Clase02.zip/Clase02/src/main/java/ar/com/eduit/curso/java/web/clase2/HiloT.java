package ar.com.eduit.curso.java.web.clase2;

import java.util.Hashtable;

public class HiloT extends Thread {
    private String nombre;
    private int time=1000;

    /**
     * Fue deprecado por Carlos el 8/7/2021
     * usar en su reemplazo     public HiloT(String nombre, int time)
     * @param nombre
     * @deprecated
     */
    @Deprecated
    public HiloT(String nombre) {
        this.nombre = nombre;
    }

    public HiloT(String nombre, int time){
        this.nombre = nombre;
        this.time = time;
    }
    
    @Override
    public void run() {
        //El método .run() es el unico que puede ejecutarse en un nuevo thread.
        for(int a=1;a<=10;a++){
            System.out.println(nombre+" "+a);
            yield();
            try { Thread.sleep(time); } catch(Exception e) {}
        }
        
    }
    
    
}
