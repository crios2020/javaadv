package ar.com.eduit.curso.java.web.clase2;

import java.util.Collections;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

public class AppBanco {

    public static void main(String[] args) {
        Cuenta cuenta=new Cuenta();
        
        Cliente cliente1=new Cliente(cuenta);
        Cliente cliente2=new Cliente(cuenta);
        
        //cliente1.start();
        //cliente2.start();
        
        
        //Hashtable<String,String>map=new Hashtable();
        //HashMap<String,String>map=new HashMap();
        Map<String,String>map=Collections.synchronizedMap(new HashMap<String,String>());
                
        map.put("lu", "Lunes");
        map.put("ma", "Martes");
        map.put("mi", "Miércoles");
        map.put("ju", "Jueves");
        map.put("vi", "Viernes");
        System.out.println(map.get("ju"));
        
        
    }
    
}
