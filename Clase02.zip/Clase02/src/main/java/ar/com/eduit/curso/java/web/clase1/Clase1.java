package ar.com.eduit.curso.java.web.clase1;

public class Clase1 {
    public static void main(String[] args) {
        
        /*
        Curso: Java Advanced 15 horas
        Días: Martes y Jueves 19:00 a 22:00 hs
        Profe: Carlos Ríos  carlos.rios@educacionit.com
        
        Alumni: alumni.educacionit.com
        user: email
        pass: dni
        
        github: https://github.com/crios2020/javaAdv
        
        Software: JDK LTS
        
        
        */
        
        System.out.println("Versión de Java: "+System.getProperty("java.version"));
        
        /*
        
            Tarea 1:    Abrir y leer el file1 en el medio1      Tiempo: 10 s
        
            Tarea 2:    Abrir y leer el file2 en el medio2      Tiempo: 10 s
        
            Tarea 3:    Abrir un form y mostrar file1 y file2   Tiempo:  1 s
        
        
        
          Tarea 1     Tarea 2  Tarea 3
        |----------|----------|-|
            10 s        10 s   1 s
        
        Tiempo total: 21 s
        
        
          Tarea 1  
        |----------|
            10 s
        
          Tarea 2  
        |----------|
            10 s
                    
                    Tarea 3
                   |-|
                    1 s
        
        Tiempo total: 11 s
        
        
          Tarea 1  
        |----------|
            10 s
        
          Tarea 2  
        |----------|
            10 s
        
        Tarea 3
        |-|
         1 s
        
        Tiempo total: 10 s
        
        */
        
        
        //Clase Thread
        HiloT hiloT1 = new HiloT("hiloT1");
        HiloT hiloT2 = new HiloT("hiloT2");
        HiloT hiloT3 = new HiloT("hiloT3");
        HiloT hiloT4 = new HiloT("hiloT4");
        
        //método .run()
        //El método no ejecuta en un nuevo thread.
        //hiloT1.run();
        //hiloT2.run();
        //hiloT3.run();
        //hiloT4.run();
        
        //método start() este método invoka al método .run() en un nuevo Thread
        //hiloT1.start();
        //hiloT2.start();
        //hiloT3.start();
        //hiloT4.start();
        
        
        
        //Interface Runnable
        HiloR hiloR1=new HiloR("hiloR1");
        HiloR hiloR2=new HiloR("hiloR2");
        HiloR hiloR3=new HiloR("hiloR3");
        HiloR hiloR4=new HiloR("hiloR4");
        //Thread anonimo
        HiloR hiloR6=new HiloR("hiloR6");
    
        Thread t1=new Thread(hiloR1);
        Thread t2=new Thread(hiloR2);
        Thread t3=new Thread(hiloR3);
        Thread t4=new Thread(hiloR4);
        //Runnable anonimo
        Thread t5=new Thread(new HiloR("hiloR5"));
        
        t1.start();
        t2.start();
        t3.start();
        t4.start();
        t5.start();
        new Thread(hiloR6).start();
        
        //Runnable y Thread anonimo
        new Thread(new HiloR("hiloR7")).start();
        
        
        
        
        
        
        
        
        
        
        
        
        
    }
}
