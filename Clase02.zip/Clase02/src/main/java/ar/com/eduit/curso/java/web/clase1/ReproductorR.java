package ar.com.eduit.curso.java.web.clase1;

import java.io.FileInputStream;
import javazoom.jl.player.Player;

public class ReproductorR implements Runnable{
    public static void main(String[] args) throws Exception {
        new Player(new FileInputStream("res/himno.mp3")).play();
    }

    @Override
    public void run() {
        try {
            new Player(new FileInputStream("res/himno.mp3")).play();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    
}
